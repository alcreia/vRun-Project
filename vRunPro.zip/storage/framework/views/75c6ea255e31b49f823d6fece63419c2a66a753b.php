<?php $__env->startSection('content'); ?>

<div>
    <p>This is main page</p>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usr\Desktop\vRunPro\resources\views/pages/index.blade.php ENDPATH**/ ?>