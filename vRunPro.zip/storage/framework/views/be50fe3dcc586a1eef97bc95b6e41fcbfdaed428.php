<?php $__env->startSection('title'); ?>
    Events -
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class='container'>
    <p>This is events page</p>
    <br>
    <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec quis lectus at nulla venenatis consectetur. In auctor sagittis felis, et consequat augue dapibus a. Nam risus ante, luctus sed tellus id, condimentum mollis sem. Morbi enim felis, fringilla vitae aliquam sollicitudin, posuere nec nisl. Etiam quis dolor maximus, tempor erat condimentum, vestibulum orci. In at fringilla leo. In hendrerit urna eget neque consequat, at accumsan turpis tempor. Integeer interdum tristique ipsum nec egestas. Sed ex enim, posuere id velit sit amet, maximus ornare sem. In a arcu nec lacus iaculis pretium et vel metus.
    </p>
    <button type="button" class="btn btn-outline-primary btn-lg">Daftar Sekarang!</button>
    <div class="row">
        <div class="col-md-6">
            <h3>Peringkat Perorangan></h3>
            <ol>
                <li>User 1</li>
                <li>User 2</li>
                <li>User 3</li>
                <li>User 4</li>
                <li>User 5</li>
            </ol>
        </div>
        <div class="col-md-6">
            <h3>Peringkat Angkatan></h3>
            <ol>
                <li>Angkatan 2012</li>
                <li>Angkatan 2014</li>
                <li>Angkatan 2015</li>
                <li>Angkatan 2017</li>
                <li>Angkatan 1999</li>
            </ol>
        </div>
        <a href="/leaderboards">>> Lihat selengkapnya</a>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usr\Desktop\vRunPro\resources\views/pages/events.blade.php ENDPATH**/ ?>