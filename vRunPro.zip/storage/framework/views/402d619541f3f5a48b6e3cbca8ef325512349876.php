<p>topShibe 2020</p>
<?php /**PATH C:\Users\usr\Desktop\vRunPro\resources\views/components/footer.blade.php ENDPATH**/ ?>