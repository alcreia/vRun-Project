<?php $__env->startSection('title'); ?>
    Leaderboards -
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <p>This is leaderboards page</p>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
          <a class="nav-link active" id="personal-tab" data-toggle="tab" href="#personal" role="tab" aria-controls="personal" aria-selected="true">Peringkat Personal</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="angkatan-tab" data-toggle="tab" href="#angkatan" role="tab" aria-controls="angkatan" aria-selected="false">Peringkat Angkatan</a>
        </li>
      </ul>
      <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="personal" role="tabpanel" aria-labelledby="personal-tab">Content</div>
        <div class="tab-pane fade" id="angkatan" role="tabpanel" aria-labelledby="angkatan-tab">Content Angkatan</div>
      </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usr\Desktop\vRunPro\resources\views/pages/leader.blade.php ENDPATH**/ ?>