<?php $__env->startSection('title'); ?>
    Registration |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <p>Register for race</p>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('register')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="raceTypeSelect">Pilih kategori lomba</label>
            <select class="form-control" name="raceType" id="raceTypeSelect" required>
                <option>--- Pilih salah satu ---</option>
                <option value="P" <?php echo e(old('raceType') == "P" ? 'selected' : ''); ?>>Personal (3,33km)</option>
                <option value="A" <?php echo e(old('raceType') == "A" ? 'selected' : ''); ?>>Angkatan (300km)</option>
            </select>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="firstNameInput">Nama</label>
                <input type="text" class="form-control" id="firstNameInput" name="firstName" required value=<?php echo e(old('firstName')); ?>>
            </div>

            <div class="form-group col-md-6">
                <label for="lastNameInput">Nama Belakang</label>
                <input type="text" class="form-control" id="lastNameInput" name="lastName" required value=<?php echo e(old('lastName')); ?>>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-4">
                <label for="genderInput">Jenis Kelamin</label>
                <select class="form-control" name="gender" id="genderInput">
                    <option>--- Pilih salah satu ---</option>
                    <option value="L" <?php echo e(old('gender') == "L" ? 'selected' : ''); ?>>Laki-laki</option>
                    <option value="P" <?php echo e(old('gender') == "P" ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>

            <div class="form-group col-md-4">
                <label for="dobInput">Tanggal Lahir</label>
                <input type="date" class="form-control" id="dobInput" name="dateOfBirth" required value=<?php echo e(old('dateOfBirth')); ?>>
            </div>

            <div class="form-group col-md-4">
                <label for="angkatanInput">Angkatan</label>
                <select name="angkatan" id="angkatanInput" class="form-control">
                    <option>--- Pilih salah satu ---</option>
                    <?php for($year = 2020; $year >=1953; $year--): ?>
                        <option value="<?php echo e($year); ?>" <?php echo e(old('angkatan') == $year ? 'selected' : ''); ?>><?php echo e($year); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="emailInput">Email</label>
                <input type="email" class="form-control" id="emailInput" name="email" required value=<?php echo e(old('email')); ?>>
            </div>

            <div class="form-group col-md-6">
                <label for="phoneInput">Nomor HP</label>
                <input type="tel" class="form-control" id="phoneInput" name="phone" required value=<?php echo e(old('phone')); ?>>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="passwordInput">Password</label>
                <input type="password" class="form-control" id="passwordInput" name="password" required>
            </div>

            <div class="form-group col-md-6">
                <label for="passwordValidate">Konfirmasi Password</label>
                <input type="password" class="form-control" id="password-confirm" name="password_confirmation" required>
            </div>
        </div>

        <div class="form-group">
            <label for="alamatInput">Alamat</label>
            <textarea class="form-control" id="alamatInput" name="alamat" rows="3" required value=<?php echo e(old('alamat')); ?>></textarea>
        </div>

        <div class="form-group">
            <input type="submit" value="Next">
        </div>

    </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usr\Desktop\vRunPro\resources\views/pages/raceregister.blade.php ENDPATH**/ ?>