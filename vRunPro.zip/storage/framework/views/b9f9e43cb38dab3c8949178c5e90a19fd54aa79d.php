<div class="navbar">
    <a href="/">Home</a>
    <a href="/events">Events</a>
    <a href="/leaderboards">Leaderboards</a>
    <?php if(auth()->guard()->guest()): ?>
        <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
        <?php if(Route::has('register')): ?>
            <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
        <?php endif; ?>
    <?php else: ?>
        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
        </a>

        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                <?php echo e(__('Logout')); ?>

            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\usr\Desktop\vRunPro\resources\views/components/header.blade.php ENDPATH**/ ?>